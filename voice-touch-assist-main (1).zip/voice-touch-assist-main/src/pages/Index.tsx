import AccessibilityTool from "@/components/AccessibilityTool";

const Index = () => {
  return <AccessibilityTool />;
};

export default Index;

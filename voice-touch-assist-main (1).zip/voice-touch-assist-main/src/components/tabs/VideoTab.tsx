import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, Play, Pause, Square, Video } from "lucide-react";

const VideoTab = ({ onTranscriptChange, isVoiceMode }) => {
  const [videoFile, setVideoFile] = useState(null);
  const [videoUrl, setVideoUrl] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);

  // Mock transcription service (replace with actual API)
  const transcribeVideo = async () => {
    setIsTranscribing(true);
    speak('Starting video transcription...');
    
    // Simulate transcription process
    await new Promise(resolve => setTimeout(resolve, 4000));
    
    const mockTranscript = `This is a mock transcription of the uploaded video file. 
    In a real implementation, this would extract audio from the video and connect to a speech-to-text service 
    like Google Cloud Speech-to-Text, Azure Speech Services, or OpenAI Whisper API.
    
    The video transcription would include:
    - All spoken dialogue and narration
    - Scene descriptions and visual context
    - Speaker identification and dialogue attribution
    - Timestamps synchronized with video playback
    - Action descriptions for accessibility
    - Background audio and music descriptions
    
    Video processing capabilities:
    - Audio extraction from video files
    - Multiple format support (MP4, AVI, MOV, etc.)
    - Real-time transcription during playback
    - Subtitle generation and export
    - Multi-language support
    
    Current video file: ${videoFile ? videoFile.name : videoUrl || 'No file selected'}
    Duration: ${formatTime(duration)}
    Resolution: Auto-detected from video metadata`;
    
    setTranscript(mockTranscript);
    onTranscriptChange(mockTranscript);
    setIsTranscribing(false);
    speak('Video transcription completed successfully.');
  };

  const speak = (text) => {
    if (window.speechSynthesis && text) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Handle voice commands
  useEffect(() => {
    const handleVoiceCommand = (event) => {
      const command = event.detail;
      
      if (command.includes('open download folder') || command.includes('browse files')) {
        fileInputRef.current?.click();
        speak('Opening file browser for video selection');
      }
      
      if (command.includes('upload') && (command.includes('.mp4') || command.includes('.avi') || command.includes('.mov'))) {
        // Extract filename from command
        const match = command.match(/upload\s+([^\s]+\.(mp4|avi|mov|mkv|webm))/i);
        if (match) {
          const filename = match[1];
          speak(`Looking for video file: ${filename}. Please select the file from the browser dialog.`);
          fileInputRef.current?.click();
        }
      }
      
      if (command.includes('play video') || command.includes('start video')) {
        if (videoFile || videoUrl) {
          handlePlayPause();
        } else {
          speak('No video file selected. Please upload a video file first.');
        }
      }
      
      if (command.includes('transcribe') || command.includes('start transcription')) {
        if (videoFile || videoUrl) {
          transcribeVideo();
        } else {
          speak('No video file selected. Please upload a video file first.');
        }
      }
      
      if (command.includes('stop video') || command.includes('pause video')) {
        if (isPlaying) {
          handlePlayPause();
        }
      }
    };

    if (isVoiceMode) {
      window.addEventListener('voiceCommand', handleVoiceCommand);
      return () => window.removeEventListener('voiceCommand', handleVoiceCommand);
    }
  }, [isVoiceMode, videoFile, videoUrl, isPlaying, duration]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('video/')) {
      setVideoFile(file);
      setVideoUrl('');
      speak(`Video file ${file.name} uploaded successfully.`);
    } else {
      speak('Please select a valid video file.');
    }
  };

  const handleUrlChange = (event) => {
    setVideoUrl(event.target.value);
    setVideoFile(null);
  };

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
        speak('Video paused');
      } else {
        videoRef.current.play();
        setIsPlaying(true);
        speak('Video playing');
      }
    }
  };

  const handleStop = () => {
    if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
      setIsPlaying(false);
      setCurrentTime(0);
      speak('Video stopped');
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
    }
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const currentVideoSrc = videoFile ? URL.createObjectURL(videoFile) : videoUrl;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Video className="h-5 w-5" />
            Video Transcription
          </CardTitle>
          <CardDescription>
            Upload a video file or provide a URL to extract and transcribe audio content
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="video-file">Upload Video File</Label>
            <div className="flex gap-2">
              <Input
                id="video-file"
                type="file"
                accept="video/*"
                onChange={handleFileUpload}
                ref={fileInputRef}
                className="flex-1"
              />
              <Button 
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
              >
                <Upload className="h-4 w-4 mr-2" />
                Browse
              </Button>
            </div>
          </div>

          {/* URL Input */}
          <div className="space-y-2">
            <Label htmlFor="video-url">Or Enter Video URL</Label>
            <Input
              id="video-url"
              type="url"
              placeholder="https://example.com/video.mp4"
              value={videoUrl}
              onChange={handleUrlChange}
            />
          </div>

          {/* Video Player */}
          {currentVideoSrc && (
            <div className="space-y-4">
              <div className="w-full aspect-video bg-muted rounded-lg overflow-hidden">
                <video
                  ref={videoRef}
                  src={currentVideoSrc}
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onEnded={() => setIsPlaying(false)}
                  className="w-full h-full object-contain"
                  controls
                />
              </div>
              
              {/* Custom Controls */}
              <div className="flex items-center gap-2">
                <Button onClick={handlePlayPause} variant="outline" size="sm">
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button onClick={handleStop} variant="outline" size="sm">
                  <Square className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </div>

              {/* Transcribe Button */}
              <Button
                onClick={transcribeVideo}
                disabled={isTranscribing}
                className="w-full"
                size="lg"
              >
                {isTranscribing ? 'Transcribing Video...' : 'Start Video Transcription'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transcript Display */}
      {transcript && (
        <Card>
          <CardHeader>
            <CardTitle>Video Transcript</CardTitle>
            <CardDescription>
              Generated transcript from the video's audio content
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={transcript}
              readOnly
              className="min-h-[200px] text-sm"
              placeholder="Video transcript will appear here..."
            />
            <div className="mt-4 flex gap-2">
              <Button
                onClick={() => navigator.clipboard.writeText(transcript)}
                variant="outline"
                size="sm"
              >
                Copy Transcript
              </Button>
              <Button
                onClick={() => speak(transcript)}
                variant="outline"
                size="sm"
              >
                Read Aloud
              </Button>
              <Button
                onClick={() => {
                  const element = document.createElement('a');
                  const file = new Blob([transcript], {type: 'text/plain'});
                  element.href = URL.createObjectURL(file);
                  element.download = 'video-transcript.txt';
                  document.body.appendChild(element);
                  element.click();
                  document.body.removeChild(element);
                }}
                variant="outline"
                size="sm"
              >
                Download Transcript
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default VideoTab;
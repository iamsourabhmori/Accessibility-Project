import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, Play, Pause, Square, Mic } from "lucide-react";

const AudioTab = ({ onTranscriptChange, isVoiceMode }) => {
  const [audioFile, setAudioFile] = useState(null);
  const [audioUrl, setAudioUrl] = useState('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  
  const audioRef = useRef(null);
  const fileInputRef = useRef(null);

  // Mock transcription service (replace with actual API)
  const transcribeAudio = async () => {
    setIsTranscribing(true);
    speak('Starting audio transcription...');
    
    // Simulate transcription process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const mockTranscript = `This is a mock transcription of the uploaded audio file. 
    In a real implementation, this would connect to a speech-to-text service like Google Cloud Speech-to-Text, 
    Azure Speech Services, or OpenAI Whisper API to generate an accurate transcript of the audio content.
    
    The transcription would include:
    - All spoken words in the audio
    - Proper punctuation and formatting
    - Speaker identification if multiple speakers
    - Timestamps for different segments
    - Confidence scores for accuracy assessment
    
    Current audio file: ${audioFile ? audioFile.name : audioUrl || 'No file selected'}`;
    
    setTranscript(mockTranscript);
    onTranscriptChange(mockTranscript);
    setIsTranscribing(false);
    speak('Audio transcription completed successfully.');
  };

  const speak = (text) => {
    if (window.speechSynthesis && text) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Handle voice commands
  useEffect(() => {
    const handleVoiceCommand = (event) => {
      const command = event.detail;
      
      if (command.includes('open download folder') || command.includes('browse files')) {
        fileInputRef.current?.click();
        speak('Opening file browser for audio selection');
      }
      
      if (command.includes('upload') && command.includes('.mp3')) {
        // Extract filename from command
        const match = command.match(/upload\s+([^\s]+\.mp3)/);
        if (match) {
          const filename = match[1];
          speak(`Looking for audio file: ${filename}. Please select the file from the browser dialog.`);
          fileInputRef.current?.click();
        }
      }
      
      if (command.includes('play audio') || command.includes('start audio')) {
        if (audioFile || audioUrl) {
          handlePlayPause();
        } else {
          speak('No audio file selected. Please upload an audio file first.');
        }
      }
      
      if (command.includes('transcribe') || command.includes('start transcription')) {
        if (audioFile || audioUrl) {
          transcribeAudio();
        } else {
          speak('No audio file selected. Please upload an audio file first.');
        }
      }
      
      if (command.includes('stop audio') || command.includes('pause audio')) {
        if (isPlaying) {
          handlePlayPause();
        }
      }
    };

    if (isVoiceMode) {
      window.addEventListener('voiceCommand', handleVoiceCommand);
      return () => window.removeEventListener('voiceCommand', handleVoiceCommand);
    }
  }, [isVoiceMode, audioFile, audioUrl, isPlaying]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('audio/')) {
      setAudioFile(file);
      setAudioUrl('');
      speak(`Audio file ${file.name} uploaded successfully.`);
    } else {
      speak('Please select a valid audio file.');
    }
  };

  const handleUrlChange = (event) => {
    setAudioUrl(event.target.value);
    setAudioFile(null);
  };

  const handlePlayPause = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
        speak('Audio paused');
      } else {
        audioRef.current.play();
        setIsPlaying(true);
        speak('Audio playing');
      }
    }
  };

  const handleStop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setIsPlaying(false);
      setCurrentTime(0);
      speak('Audio stopped');
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const formatTime = (time) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const currentAudioSrc = audioFile ? URL.createObjectURL(audioFile) : audioUrl;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mic className="h-5 w-5" />
            Audio Transcription
          </CardTitle>
          <CardDescription>
            Upload an audio file or provide a URL to generate a complete transcript
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="audio-file">Upload Audio File</Label>
            <div className="flex gap-2">
              <Input
                id="audio-file"
                type="file"
                accept="audio/*"
                onChange={handleFileUpload}
                ref={fileInputRef}
                className="flex-1"
              />
              <Button 
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
              >
                <Upload className="h-4 w-4 mr-2" />
                Browse
              </Button>
            </div>
          </div>

          {/* URL Input */}
          <div className="space-y-2">
            <Label htmlFor="audio-url">Or Enter Audio URL</Label>
            <Input
              id="audio-url"
              type="url"
              placeholder="https://example.com/audio.mp3"
              value={audioUrl}
              onChange={handleUrlChange}
            />
          </div>

          {/* Audio Player */}
          {currentAudioSrc && (
            <div className="space-y-4">
              <audio
                ref={audioRef}
                src={currentAudioSrc}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={handleLoadedMetadata}
                onEnded={() => setIsPlaying(false)}
                className="w-full"
                controls
              />
              
              {/* Custom Controls */}
              <div className="flex items-center gap-2">
                <Button onClick={handlePlayPause} variant="outline" size="sm">
                  {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                </Button>
                <Button onClick={handleStop} variant="outline" size="sm">
                  <Square className="h-4 w-4" />
                </Button>
                <span className="text-sm text-muted-foreground">
                  {formatTime(currentTime)} / {formatTime(duration)}
                </span>
              </div>

              {/* Transcribe Button */}
              <Button
                onClick={transcribeAudio}
                disabled={isTranscribing}
                className="w-full"
                size="lg"
              >
                {isTranscribing ? 'Transcribing...' : 'Start Transcription'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transcript Display */}
      {transcript && (
        <Card>
          <CardHeader>
            <CardTitle>Audio Transcript</CardTitle>
            <CardDescription>
              Generated transcript from the uploaded audio file
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={transcript}
              readOnly
              className="min-h-[200px] text-sm"
              placeholder="Transcript will appear here..."
            />
            <div className="mt-4 flex gap-2">
              <Button
                onClick={() => navigator.clipboard.writeText(transcript)}
                variant="outline"
                size="sm"
              >
                Copy Transcript
              </Button>
              <Button
                onClick={() => speak(transcript)}
                variant="outline"
                size="sm"
              >
                Read Aloud
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AudioTab;
import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileText, Play, Pause, Square, Download } from "lucide-react";

const DocumentTab = ({ onTranscriptChange, isVoiceMode }) => {
  const [documentFile, setDocumentFile] = useState(null);
  const [documentUrl, setDocumentUrl] = useState('');
  const [documentText, setDocumentText] = useState('');
  const [isReading, setIsReading] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentLine, setCurrentLine] = useState(0);
  const [lines, setLines] = useState([]);
  const [readingSpeed, setReadingSpeed] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const fileInputRef = useRef(null);
  const utteranceRef = useRef(null);
  const textDisplayRef = useRef(null);

  // Process document file
  const processDocument = async (file) => {
    if (!file) return;

    speak(`Processing document: ${file.name}`);
    
    if (file.type === 'text/plain') {
      const text = await file.text();
      setDocumentText(text);
      setLines(text.split('\n').filter(line => line.trim()));
      onTranscriptChange(text);
      speak('Text document loaded successfully. Ready to read aloud.');
    } else if (file.type === 'application/pdf') {
      // Mock PDF processing - in real implementation, use pdf-parse or similar
      const mockPdfText = `This is a mock PDF document processing result.
      
In a real implementation, this would use libraries like:
- pdf-parse for Node.js environments
- PDF.js for browser-based PDF parsing
- pdfreader for lightweight PDF text extraction

The document reader would provide:

ACCESSIBILITY FEATURES:
- Line-by-line reading with visual highlighting
- Adjustable reading speed control
- Pause and resume functionality
- Navigation to specific sections
- Text size and contrast adjustments

DOCUMENT PROCESSING:
- Text extraction from PDF files
- Support for multiple file formats (PDF, DOC, TXT)
- Structured content recognition
- Table and list formatting preservation
- Image and caption handling

READING CAPABILITIES:
- Natural speech synthesis
- Multiple voice options
- Speed and pitch control
- Pronunciation customization
- Language detection and switching

NAVIGATION FEATURES:
- Bookmark creation and management
- Search functionality within documents
- Chapter and section jumping
- Progress tracking and resumption
- Reading history and statistics

Document: ${file.name}
Type: PDF Document
Pages: Simulated multi-page content
Size: ${(file.size / 1024).toFixed(2)} KB

This comprehensive document reader ensures that users with visual impairments can access any written content through high-quality text-to-speech functionality with full navigation control.`;

      setDocumentText(mockPdfText);
      setLines(mockPdfText.split('\n').filter(line => line.trim()));
      onTranscriptChange(mockPdfText);
      speak('PDF document processed successfully. Ready to read aloud.');
    } else {
      speak('Unsupported file format. Please upload a PDF or text file.');
    }
  };

  // Process document from URL
  const processDocumentFromUrl = async () => {
    if (!documentUrl.trim()) {
      speak('Please enter a valid document URL');
      return;
    }

    setIsProcessing(true);
    speak('Processing document from URL. Please wait.');

    try {
      // Mock URL processing - in real implementation, you'd fetch and parse the document
      const mockUrlText = `Document from URL: ${documentUrl}

This is a sample document content loaded from the provided URL.

ACCESSIBILITY TRANSCRIPTION TOOL

This comprehensive tool supports multiple input methods:

1. FILE UPLOAD PROCESSING:
   - Direct file upload from local storage
   - Support for PDF, TXT, DOC, and DOCX formats
   - Drag and drop functionality
   - File validation and error handling

2. URL DOCUMENT PROCESSING:
   - Remote document fetching via URLs
   - Direct links to document files
   - Online document repositories
   - Cloud storage document links

3. READING CAPABILITIES:
   - Line-by-line text-to-speech
   - Adjustable reading speed control
   - Visual highlighting during reading
   - Pause, resume, and stop functionality

4. NAVIGATION FEATURES:
   - Click any line to jump to position
   - Progress tracking during reading
   - Smooth scrolling to current line
   - Line numbering for reference

5. VOICE COMMAND INTEGRATION:
   - "Document Tab" - Switch to document mode
   - "Open download folder" - Browse for files
   - "Upload [filename]" - Voice file selection
   - "Run document" - Start reading process
   - "Pause reading" - Pause current reading
   - "Stop reading" - Stop and reset

6. ACCESSIBILITY COMPLIANCE:
   - WCAG 2.1 AA compliance
   - Screen reader compatibility
   - High contrast visual indicators
   - Keyboard navigation support
   - Focus management and ARIA labels

URL Source: ${documentUrl}
Processing Date: ${new Date().toLocaleString()}
Content Type: Mock Document Content
Status: Successfully Processed

This document reader provides comprehensive accessibility features for users with visual impairments, ensuring equal access to written content through advanced text-to-speech technology.`;

      setDocumentText(mockUrlText);
      setLines(mockUrlText.split('\n').filter(line => line.trim()));
      onTranscriptChange(mockUrlText);
      speak('Document from URL processed successfully. Ready to read aloud.');
    } catch (error) {
      speak('Error processing document from URL. Please check the URL and try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const speak = (text) => {
    if (window.speechSynthesis && text) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = readingSpeed;
      utterance.pitch = 1;
      utterance.volume = 1;
      window.speechSynthesis.speak(utterance);
    }
  };

  const startReading = () => {
    if (!lines.length) {
      speak('No document loaded. Please upload a document first.');
      return;
    }

    setIsReading(true);
    setIsPaused(false);
    readNextLine();
  };

  const readNextLine = () => {
    if (currentLine >= lines.length) {
      stopReading();
      speak('Document reading completed.');
      return;
    }

    const line = lines[currentLine];
    if (line.trim()) {
      // Highlight current line
      highlightLine(currentLine);
      
      // Create utterance for current line
      utteranceRef.current = new SpeechSynthesisUtterance(line);
      utteranceRef.current.rate = readingSpeed;
      utteranceRef.current.pitch = 1;
      utteranceRef.current.volume = 1;
      
      utteranceRef.current.onend = () => {
        if (isReading && !isPaused) {
          setCurrentLine(prev => {
            const nextLine = prev + 1;
            setTimeout(() => readNextLine(), 200); // Small pause between lines
            return nextLine;
          });
        }
      };

      utteranceRef.current.onerror = () => {
        console.error('Speech synthesis error');
        stopReading();
      };

      window.speechSynthesis.speak(utteranceRef.current);
    } else {
      // Skip empty lines
      setCurrentLine(prev => prev + 1);
      setTimeout(() => readNextLine(), 100);
    }
  };

  const pauseReading = () => {
    setIsPaused(true);
    window.speechSynthesis.pause();
    speak('Reading paused.');
  };

  const resumeReading = () => {
    setIsPaused(false);
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    } else {
      readNextLine();
    }
    speak('Reading resumed.');
  };

  const stopReading = () => {
    setIsReading(false);
    setIsPaused(false);
    setCurrentLine(0);
    window.speechSynthesis.cancel();
    clearHighlight();
  };

  const highlightLine = (lineIndex) => {
    if (textDisplayRef.current) {
      const lineElements = textDisplayRef.current.querySelectorAll('.document-line');
      lineElements.forEach((el, idx) => {
        if (idx === lineIndex) {
          el.classList.add('bg-primary', 'text-primary-foreground', 'font-semibold');
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        } else {
          el.classList.remove('bg-primary', 'text-primary-foreground', 'font-semibold');
        }
      });
    }
  };

  const clearHighlight = () => {
    if (textDisplayRef.current) {
      const lineElements = textDisplayRef.current.querySelectorAll('.document-line');
      lineElements.forEach(el => {
        el.classList.remove('bg-primary', 'text-primary-foreground', 'font-semibold');
      });
    }
  };

  // Handle voice commands
  useEffect(() => {
    const handleVoiceCommand = (event) => {
      const command = event.detail;
      
      if (command.includes('open download folder') || command.includes('browse files')) {
        fileInputRef.current?.click();
        speak('Opening file browser for document selection');
      }
      
      if (command.includes('upload') && (command.includes('.pdf') || command.includes('.txt') || command.includes('.doc'))) {
        // Extract filename from command
        const match = command.match(/upload\s+([^\s]+\.(pdf|txt|doc|docx))/i);
        if (match) {
          const filename = match[1];
          speak(`Looking for document file: ${filename}. Please select the file from the browser dialog.`);
          fileInputRef.current?.click();
        }
      }
      
      if (command.includes('run document') || command.includes('start reading') || command.includes('read document')) {
        if (documentText) {
          startReading();
        } else {
          speak('No document loaded. Please upload a document first.');
        }
      }
      
      if (command.includes('pause reading') || command.includes('stop reading')) {
        if (isReading && !isPaused) {
          pauseReading();
        } else if (isReading && isPaused) {
          resumeReading();
        }
      }
      
      if (command.includes('stop document') || command.includes('stop reading')) {
        if (isReading) {
          stopReading();
        }
      }
    };

    if (isVoiceMode) {
      window.addEventListener('voiceCommand', handleVoiceCommand);
      return () => window.removeEventListener('voiceCommand', handleVoiceCommand);
    }
  }, [isVoiceMode, documentText, isReading, isPaused]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file && (file.type === 'text/plain' || file.type === 'application/pdf' || file.type.includes('document'))) {
      setDocumentFile(file);
      processDocument(file);
    } else {
      speak('Please select a valid document file (PDF, TXT, or DOC).');
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Document Reader
          </CardTitle>
          <CardDescription>
            Upload a document to read it aloud with line-by-line highlighting
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="document-file">Upload Document</Label>
            <div className="flex gap-2">
              <Input
                id="document-file"
                type="file"
                accept=".pdf,.txt,.doc,.docx"
                onChange={handleFileUpload}
                ref={fileInputRef}
                className="flex-1"
              />
              <Button 
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
              >
                <Upload className="h-4 w-4 mr-2" />
                Browse
              </Button>
            </div>
          </div>

          {/* URL Input */}
          <div className="space-y-2">
            <Label htmlFor="document-url">Or Enter Document URL</Label>
            <div className="flex gap-2">
              <Input
                id="document-url"
                type="url"
                placeholder="https://example.com/document.pdf"
                value={documentUrl}
                onChange={(e) => setDocumentUrl(e.target.value)}
                className="flex-1"
              />
              <Button 
                onClick={processDocumentFromUrl}
                disabled={isProcessing || !documentUrl.trim()}
                variant="outline"
              >
                {isProcessing ? 'Processing...' : 'Process URL'}
              </Button>
            </div>
          </div>

          {/* Reading Controls */}
          {documentText && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Label htmlFor="reading-speed">Reading Speed:</Label>
                <input
                  id="reading-speed"
                  type="range"
                  min="0.5"
                  max="2"
                  step="0.1"
                  value={readingSpeed}
                  onChange={(e) => setReadingSpeed(parseFloat(e.target.value))}
                  className="flex-1"
                />
                <span className="text-sm text-muted-foreground">{readingSpeed}x</span>
              </div>

              <div className="flex gap-2">
                {!isReading ? (
                  <Button onClick={startReading} size="lg">
                    <Play className="h-4 w-4 mr-2" />
                    Start Reading
                  </Button>
                ) : (
                  <>
                    {!isPaused ? (
                      <Button onClick={pauseReading} variant="outline" size="lg">
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                    ) : (
                      <Button onClick={resumeReading} size="lg">
                        <Play className="h-4 w-4 mr-2" />
                        Resume
                      </Button>
                    )}
                    <Button onClick={stopReading} variant="destructive" size="lg">
                      <Square className="h-4 w-4 mr-2" />
                      Stop
                    </Button>
                  </>
                )}
              </div>

              {isReading && (
                <div className="text-sm text-muted-foreground">
                  Reading line {currentLine + 1} of {lines.length}
                  {isPaused && ' (Paused)'}
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Document Display */}
      {documentText && (
        <Card>
          <CardHeader>
            <CardTitle>Document Content</CardTitle>
            <CardDescription>
              {documentFile?.name} - Line-by-line display with reading highlights
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div 
              ref={textDisplayRef}
              className="max-h-96 overflow-y-auto p-4 border rounded-lg bg-muted/30"
            >
              {lines.map((line, index) => (
                <div
                  key={index}
                  className="document-line p-2 rounded transition-colors duration-200 cursor-pointer hover:bg-muted/50"
                  onClick={() => {
                    if (!isReading) {
                      setCurrentLine(index);
                      speak(line);
                    }
                  }}
                >
                  <span className="text-xs text-muted-foreground mr-2">
                    {index + 1}:
                  </span>
                  {line}
                </div>
              ))}
            </div>
            
            <div className="mt-4 flex gap-2 flex-wrap">
              <Button
                onClick={() => navigator.clipboard.writeText(documentText)}
                variant="outline"
                size="sm"
              >
                Copy Text
              </Button>
              <Button
                onClick={() => {
                  const element = document.createElement('a');
                  const file = new Blob([documentText], {type: 'text/plain'});
                  element.href = URL.createObjectURL(file);
                  element.download = 'document-text.txt';
                  document.body.appendChild(element);
                  element.click();
                  document.body.removeChild(element);
                }}
                variant="outline"
                size="sm"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Text
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Document Reader Features */}
      <Card>
        <CardHeader>
          <CardTitle>Document Reader Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-semibold mb-2">File Support</h4>
              <p className="text-muted-foreground">
                PDF, TXT, DOC, and DOCX files with text extraction
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Reading Controls</h4>
              <p className="text-muted-foreground">
                Play, pause, stop, and speed adjustment for comfortable listening
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Visual Highlighting</h4>
              <p className="text-muted-foreground">
                Line-by-line highlighting synchronized with speech
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Navigation</h4>
              <p className="text-muted-foreground">
                Click any line to jump to that position in the document
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DocumentTab;
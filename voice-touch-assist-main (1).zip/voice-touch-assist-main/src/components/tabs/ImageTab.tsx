import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, Image, Eye, Download } from "lucide-react";

const ImageTab = ({ onTranscriptChange, isVoiceMode }) => {
  const [imageFile, setImageFile] = useState(null);
  const [imageUrl, setImageUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [caption, setCaption] = useState('');
  const [preview, setPreview] = useState('');
  
  const fileInputRef = useRef(null);

  // Mock image captioning service (replace with actual API)
  const analyzeImage = async () => {
    setIsAnalyzing(true);
    speak('Starting image analysis and caption generation...');
    
    // Simulate image analysis process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const mockCaption = `This is a mock caption generated for the uploaded image. 
    In a real implementation, this would connect to an AI vision service like:
    
    - Google Cloud Vision API
    - Azure Computer Vision
    - AWS Rekognition
    - OpenAI GPT-4 Vision
    - Microsoft Cognitive Services
    
    The image analysis would provide:
    
    VISUAL DESCRIPTION:
    A detailed description of what is visible in the image, including objects, people, animals, scenery, colors, composition, and spatial relationships between elements.
    
    SCENE CONTEXT:
    Information about the setting, environment, time of day, weather conditions, and overall mood or atmosphere of the image.
    
    TEXT DETECTION:
    Any visible text, signs, labels, or written content within the image would be detected and transcribed.
    
    ACCESSIBILITY FEATURES:
    - Alternative text descriptions for screen readers
    - Color and contrast information
    - Spatial layout descriptions
    - Important visual elements highlighted
    
    CONTENT CATEGORIZATION:
    - Subject matter classification
    - Content type identification
    - Appropriate audience assessment
    - Cultural and contextual information
    
    Image file: ${imageFile ? imageFile.name : imageUrl || 'No file selected'}
    
    This comprehensive analysis ensures that visually impaired users can understand the complete context and content of any image through detailed verbal descriptions.`;
    
    setCaption(mockCaption);
    onTranscriptChange(mockCaption);
    setIsAnalyzing(false);
    speak('Image analysis completed. Caption generated successfully.');
  };

  const speak = (text) => {
    if (window.speechSynthesis && text) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Handle voice commands
  useEffect(() => {
    const handleVoiceCommand = (event) => {
      const command = event.detail;
      
      if (command.includes('open download folder') || command.includes('browse files')) {
        fileInputRef.current?.click();
        speak('Opening file browser for image selection');
      }
      
      if (command.includes('upload') && (command.includes('.jpg') || command.includes('.jpeg') || command.includes('.png') || command.includes('.gif'))) {
        // Extract filename from command
        const match = command.match(/upload\s+([^\s]+\.(jpg|jpeg|png|gif|bmp|webp))/i);
        if (match) {
          const filename = match[1];
          speak(`Looking for image file: ${filename}. Please select the file from the browser dialog.`);
          fileInputRef.current?.click();
        }
      }
      
      if (command.includes('run image') || command.includes('analyze image') || command.includes('describe image')) {
        if (imageFile || imageUrl) {
          analyzeImage();
        } else {
          speak('No image file selected. Please upload an image file first.');
        }
      }
      
      if (command.includes('read caption') || command.includes('describe image')) {
        if (caption) {
          speak(caption);
        } else {
          speak('No caption available. Please analyze an image first.');
        }
      }
    };

    if (isVoiceMode) {
      window.addEventListener('voiceCommand', handleVoiceCommand);
      return () => window.removeEventListener('voiceCommand', handleVoiceCommand);
    }
  }, [isVoiceMode, imageFile, imageUrl, caption]);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file && file.type.startsWith('image/')) {
      setImageFile(file);
      setImageUrl('');
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target?.result as string || '');
      reader.readAsDataURL(file);
      speak(`Image file ${file.name} uploaded successfully.`);
    } else {
      speak('Please select a valid image file.');
    }
  };

  const handleUrlChange = (event) => {
    const url = event.target.value;
    setImageUrl(url);
    setImageFile(null);
    setPreview(url);
  };

  const currentImageSrc = imageFile ? URL.createObjectURL(imageFile) : imageUrl;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Image className="h-5 w-5" />
            Image Caption Generation
          </CardTitle>
          <CardDescription>
            Upload an image file or provide a URL to generate descriptive captions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* File Upload */}
          <div className="space-y-2">
            <Label htmlFor="image-file">Upload Image File</Label>
            <div className="flex gap-2">
              <Input
                id="image-file"
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                ref={fileInputRef}
                className="flex-1"
              />
              <Button 
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
              >
                <Upload className="h-4 w-4 mr-2" />
                Browse
              </Button>
            </div>
          </div>

          {/* URL Input */}
          <div className="space-y-2">
            <Label htmlFor="image-url">Or Enter Image URL</Label>
            <Input
              id="image-url"
              type="url"
              placeholder="https://example.com/image.jpg"
              value={imageUrl}
              onChange={handleUrlChange}
            />
          </div>

          {/* Image Preview */}
          {currentImageSrc && (
            <div className="space-y-4">
              <div className="w-full max-w-2xl mx-auto">
                <img
                  src={currentImageSrc}
                  alt="Uploaded image preview"
                  className="w-full h-auto max-h-96 object-contain rounded-lg border"
                  onLoad={() => speak('Image loaded and displayed successfully.')}
                  onError={() => speak('Error loading image. Please check the file or URL.')}
                />
              </div>

              {/* Analyze Button */}
              <div className="flex gap-2 justify-center">
                <Button
                  onClick={analyzeImage}
                  disabled={isAnalyzing}
                  className="px-8"
                  size="lg"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  {isAnalyzing ? 'Analyzing Image...' : 'Generate Caption'}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Caption Display */}
      {caption && (
        <Card>
          <CardHeader>
            <CardTitle>Image Caption</CardTitle>
            <CardDescription>
              AI-generated description of the uploaded image
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={caption}
              readOnly
              className="min-h-[200px] text-sm"
              placeholder="Image caption will appear here..."
            />
            <div className="mt-4 flex gap-2 flex-wrap">
              <Button
                onClick={() => navigator.clipboard.writeText(caption)}
                variant="outline"
                size="sm"
              >
                Copy Caption
              </Button>
              <Button
                onClick={() => speak(caption)}
                variant="outline"
                size="sm"
              >
                Read Caption Aloud
              </Button>
              <Button
                onClick={() => {
                  const element = document.createElement('a');
                  const file = new Blob([caption], {type: 'text/plain'});
                  element.href = URL.createObjectURL(file);
                  element.download = 'image-caption.txt';
                  document.body.appendChild(element);
                  element.click();
                  document.body.removeChild(element);
                }}
                variant="outline"
                size="sm"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Caption
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Image Analysis Info */}
      <Card>
        <CardHeader>
          <CardTitle>Image Analysis Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-semibold mb-2">Visual Description</h4>
              <p className="text-muted-foreground">
                Detailed description of objects, people, scenes, and visual elements
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Accessibility Support</h4>
              <p className="text-muted-foreground">
                Screen reader compatible descriptions and spatial information
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Text Detection</h4>
              <p className="text-muted-foreground">
                Recognition and transcription of any text visible in images
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Context Analysis</h4>
              <p className="text-muted-foreground">
                Scene understanding, mood detection, and environmental context
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ImageTab;
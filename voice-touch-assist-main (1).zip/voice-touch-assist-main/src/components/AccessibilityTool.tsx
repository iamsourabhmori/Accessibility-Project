import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Mic, MicOff, Volume2, VolumeX } from "lucide-react";
import AudioTab from './tabs/AudioTab';
import VideoTab from './tabs/VideoTab';
import ImageTab from './tabs/ImageTab';
import DocumentTab from './tabs/DocumentTab';

const AccessibilityTool = () => {
  const [activeTab, setActiveTab] = useState('audio');
  const [isVoiceMode, setIsVoiceMode] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [voiceCommand, setVoiceCommand] = useState('');
  const [transcript, setTranscript] = useState('');
  
  const recognitionRef = useRef(null);
  const synthRef = useRef(window.speechSynthesis);

  // Initialize speech recognition
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = true;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'en-US';

      recognitionRef.current.onresult = (event) => {
        const current = event.resultIndex;
        const transcript = event.results[current][0].transcript.toLowerCase().trim();
        
        if (event.results[current].isFinal) {
          setVoiceCommand(transcript);
          handleVoiceCommand(transcript);
        }
      };

      recognitionRef.current.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        if (isVoiceMode && isListening) {
          // Restart listening if voice mode is still active
          setTimeout(() => {
            if (recognitionRef.current && isVoiceMode) {
              recognitionRef.current.start();
            }
          }, 100);
        }
      };
    } else {
      speak('Speech recognition not supported in this browser.');
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [isVoiceMode, isListening]);

  const speak = (text) => {
    if (synthRef.current && text) {
      synthRef.current.cancel(); // Cancel any ongoing speech
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;
      synthRef.current.speak(utterance);
    }
  };

  const handleVoiceCommand = (command) => {
    console.log('Voice command received:', command);
    
    // Tab navigation commands
    if (command.includes('audio tab')) {
      setActiveTab('audio');
      speak('Switched to Audio tab');
      return;
    }
    
    if (command.includes('video tab')) {
      setActiveTab('video');
      speak('Switched to Video tab');
      return;
    }
    
    if (command.includes('image tab')) {
      setActiveTab('image');
      speak('Switched to Image tab');
      return;
    }
    
    if (command.includes('document tab')) {
      setActiveTab('document');
      speak('Switched to Document tab');
      return;
    }

    // Exit commands
    if (command.includes('exit') || command.includes('stop')) {
      setIsVoiceMode(false);
      setIsListening(false);
      speak('Voice assistant stopped');
      return;
    }

    // Pass command to current tab component
    const event = new CustomEvent('voiceCommand', { detail: command });
    window.dispatchEvent(event);
  };

  const toggleVoiceMode = () => {
    if (!isVoiceMode) {
      setIsVoiceMode(true);
      setIsListening(true);
      speak('Voice assistant activated. You can now use voice commands. Say Audio Tab, Video Tab, Image Tab, or Document Tab to navigate.');
      
      setTimeout(() => {
        if (recognitionRef.current) {
          recognitionRef.current.start();
        }
      }, 3000); // Wait for speech to finish
    } else {
      setIsVoiceMode(false);
      setIsListening(false);
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      synthRef.current.cancel();
      speak('Voice assistant deactivated');
    }
  };

  const toggleAudio = () => {
    if (synthRef.current.speaking) {
      synthRef.current.cancel();
    } else if (transcript) {
      speak(transcript);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-4xl font-bold text-center mb-2">
            Accessibility Transcription Tool
          </h1>
          <p className="text-center text-muted-foreground mb-4">
            Supporting both manual and voice-based interactions for inclusive access
          </p>
          
          {/* Control Buttons */}
          <div className="flex justify-center gap-4 mb-4">
            <Button
              onClick={toggleVoiceMode}
              variant={isVoiceMode ? "destructive" : "outline"}
              size="lg"
              className="text-lg px-6 py-3"
            >
              {isVoiceMode ? (
                <>
                  <MicOff className="mr-2 h-5 w-5" />
                  Stop Voice Assistant
                </>
              ) : (
                <>
                  <Mic className="mr-2 h-5 w-5" />
                  Start Voice Assistant
                </>
              )}
            </Button>
            
            <Button
              onClick={toggleAudio}
              variant="outline"
              size="lg"
              className="text-lg px-6 py-3"
            >
              {synthRef.current && synthRef.current.speaking ? (
                <>
                  <VolumeX className="mr-2 h-5 w-5" />
                  Stop Audio
                </>
              ) : (
                <>
                  <Volume2 className="mr-2 h-5 w-5" />
                  Read Transcript
                </>
              )}
            </Button>
          </div>

          {/* Voice Status */}
          {isVoiceMode && (
            <div className="text-center">
              <div className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-4 py-2 rounded-lg">
                <div className={`w-3 h-3 rounded-full ${isListening ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
                <span>Voice Mode: {isListening ? 'Listening...' : 'Inactive'}</span>
              </div>
              {voiceCommand && (
                <p className="mt-2 text-sm text-muted-foreground">
                  Last command: "{voiceCommand}"
                </p>
              )}
            </div>
          )}
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 h-14 text-lg">
            <TabsTrigger value="audio" className="py-3">
              Audio
            </TabsTrigger>
            <TabsTrigger value="video" className="py-3">
              Video
            </TabsTrigger>
            <TabsTrigger value="image" className="py-3">
              Image
            </TabsTrigger>
            <TabsTrigger value="document" className="py-3">
              Document
            </TabsTrigger>
          </TabsList>

          <TabsContent value="audio" className="mt-6">
            <AudioTab onTranscriptChange={setTranscript} isVoiceMode={isVoiceMode} />
          </TabsContent>

          <TabsContent value="video" className="mt-6">
            <VideoTab onTranscriptChange={setTranscript} isVoiceMode={isVoiceMode} />
          </TabsContent>

          <TabsContent value="image" className="mt-6">
            <ImageTab onTranscriptChange={setTranscript} isVoiceMode={isVoiceMode} />
          </TabsContent>

          <TabsContent value="document" className="mt-6">
            <DocumentTab onTranscriptChange={setTranscript} isVoiceMode={isVoiceMode} />
          </TabsContent>
        </Tabs>

        {/* Instructions */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>How to Use</CardTitle>
            <CardDescription>
              This tool supports two interaction modes for maximum accessibility
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Manual Mode (Default)</h3>
              <p className="text-sm text-muted-foreground">
                Use buttons and file uploads to interact with the tool. Perfect for users with hands who can see or navigate visually.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Voice Mode</h3>
              <p className="text-sm text-muted-foreground">
                Activate voice assistant for hands-free operation. Use commands like:
              </p>
              <ul className="text-sm text-muted-foreground mt-2 ml-4 list-disc">
                <li>"Audio Tab" - Switch to audio processing</li>
                <li>"Video Tab" - Switch to video processing</li>
                <li>"Image Tab" - Switch to image processing</li>
                <li>"Document Tab" - Switch to document processing</li>
                <li>"Play Audio/Video" - Start media playback</li>
                <li>"Transcribe" - Start transcription process</li>
                <li>"Exit" or "Stop" - Deactivate voice assistant</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AccessibilityTool;